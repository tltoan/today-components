Today welcome landing — standalone source

Add TodayIntro.swift and TodayWelcomeIntro.swift to the same iOS 17+ target.
Use the existing registered TestTheFuture-Medium font from Today.

TodayWelcomeIntro(onBegin: beginOnboarding).ignoresSafeArea()

TodayWelcomePreview() is the review-only demo: Begin replays the entrance.
The supplied welcome source and locally located TodayIntro dependency are unchanged.
No native app integration is performed by this archive.
